<?php



//molty dimention array

$wheel = array(
    
    //↓Start item 1

        "101" => array(
                        'name' => "wheel 1", 
                        'price' => "100",
                        'img-detail' => "assets/img/shop/shop-d-1-1.jpg",
                        'img-main' => "assets/img/shop/shop-1-1.jpg",
                        'description' => "Progressively supply clicks-and-mortar human capital through enterprise-wide web services. Objectively provide access to extensible processes through 24/365 solutions. Professionally actualize client-based leadership via out-of-the-box supply chains.",
                        'sku'=> "578",
        ),
    //↑End of item 1
    //↓Start item 2

        "102" => array(
                        'name' => "wheel 2", 
                        'price' => "100",
                        'img-detail' => "assets/img/shop/shop-d-1-2.jpg",
                        'img-main' => "assets/img/shop/shop-1-2.jpg",
                        'description' => "Progressively supply clicks-and-mortar human capital through enterprise-wide web services. Objectively provide access to extensible processes through 24/365 solutions. Professionally actualize client-based leadership via out-of-the-box supply chains.",
                        'sku'=> "578",
        ),
    //↑End of item 2
    //↓Start item 3

        "103" => array(
                        'name' => "wheel 3", 
                        'price' => "100",
                        'img-detail' => "assets/img/shop/shop-d-1-3.jpg",
                        'img-main' => "assets/img/shop/shop-1-3.jpg",
                        'description' => "Progressively supply clicks-and-mortar human capital through enterprise-wide web services. Objectively provide access to extensible processes through 24/365 solutions. Professionally actualize client-based leadership via out-of-the-box supply chains.",
                        'sku'=> "578",
        ),
    //↑End of item 3
    //↓Start item 4

        "104" => array(
                        'name' => "wheel 4", 
                        'price' => "100",
                        'img-detail' => "assets/img/shop/shop-d-1-4.jpg",
                        'img-main' => "assets/img/shop/shop-1-4.jpg",
                        'description' => "Progressively supply clicks-and-mortar human capital through enterprise-wide web services. Objectively provide access to extensible processes through 24/365 solutions. Professionally actualize client-based leadership via out-of-the-box supply chains.",
                        'sku'=> "578",
        ),
    //↑End of item 4

);

//↑end of array

