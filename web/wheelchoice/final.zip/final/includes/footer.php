<footer class="footer-wrapper footer-layout1" data-bg-src="assets/img/bg/bg-10.jpg">
        <div class="widget-area pt-100 pb-50">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-xl-4">
                        <div class="widget footer-widget  ">
                            <h3 class="widget_title">About Company</h3>
                            <div class="vs-widget-about">
                                <p class="widget-about-text mb-25 pe-xl-5"> Wheel Choice was founded in 2012 with its emphasis on bringing unique
wheels built to the most....<a href="about.php">Read more</a></p>
                                
                            </div>
                        </div>
                    </div>
                  

                </div>
            </div>
        </div>
        <div class="copyright-style1">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12">
                        <button type="button" class="footer-scroll scrollToTop"><i class="far fa-angle-up"></i></button>
                    </div>
                    <div class="col-md-8 col-lg-6 text-center text-md-start">
                        <p class="py-2 py-md-0 mb-0">Copyright <i class="fal fa-copyright"></i> <?php echo date('Y'); ?> <a class="text-white me-1" href="index.php">Wheel Choice.</a>All rights reserved by<a class="text-white ms-1" href="https://peneh.com">Peneh</a>.</p>
                    </div>
                   <!-- <div class="col-md-4 col-lg-6 text-end d-none d-md-block">
                        <div class="footer-payment">
                            <img src="assets/img/footer/payment.png" alt="Payment Image">
                        </div>-->
                    </div>
                </div>
            </div>
        </div>
    </footer>



    <!--********************************
			Code End  Here 
	******************************** -->




    <!--==============================
        All Js File
    ============================== -->
    <!-- Jquery -->
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <!-- Slick Slider -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Layerslider -->
    <script src="assets/js/layerslider.utils.js"></script>
    <script src="assets/js/layerslider.transitions.js"></script>
    <script src="assets/js/layerslider.kreaturamedia.jquery.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Magnific Popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Isotope Filter -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!-- Custom Carousel -->
    <script src="assets/js/vscustom-carousel.min.js"></script>
    <!-- Form Js -->
    <script src="assets/js/ajax-mail.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/main.js"></script>

</body>

</html>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-137231598-1">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-137231598-1');
</script>